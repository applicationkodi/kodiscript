﻿#--------------------------------------------------------------------------------- 
#The sample scripts are not supported under any Microsoft standard support 
#program or service. The sample scripts are provided AS IS without warranty  
#of any kind. Microsoft further disclaims all implied warranties including,  
#without limitation, any implied warranties of merchantability or of fitness for 
#a particular purpose. The entire risk arising out of the use or performance of  
#the sample scripts and documentation remains with you. In no event shall 
#Microsoft, its authors, or anyone else involved in the creation, production, or 
#delivery of the scripts be liable for any damages whatsoever (including, 
#without limitation, damages for loss of business profits, business interruption, 
#loss of business information, or other pecuniary loss) arising out of the use 
#of or inability to use the sample scripts or documentation, even if Microsoft 
#has been advised of the possibility of such damages 
#--------------------------------------------------------------------------------- 

#requires -Version 2.0

<#
 	.SYNOPSIS
        This script sample can get all current url of tabs in Internet Explorer and supports automatically open the last opened urls.
    .DESCRIPTION
        This script sample can get all current url of tabs in Internet Explorer and supports automatically open the last opened urls.
    .PARAMETER  ExportCsvFile
        Specifies the path you want to export the csv file.
    .PARAMETER  OpenURL
        Specifies the path you want to import csv file.
    .EXAMPLE
        C:\PS> F:\Script\IEabsAddress.ps1 -ExportCsvFile D:\IEurls.csv
        
        Successfully exported csv file on 'D:\IEurls.csv'

        This command line shows how to get current url of tabs and export to specified location.
    .EXAMPLE
        C:\PS> F:\Script\IETabsAddress.ps1 -OpenURL D:\IEurls.csv
        
        Successfully open 'http://www.microsoft.com/en-us/default.aspx' in Internet Explorer.
        Successfully open 'http://windows.microsoft.com/en-us/windows-8/meet' in Internet Explorer.
        Successfully open 'http://www.microsoft.com/en-us/download/default.aspx?WT.mc_id=MSCOM_HP_us_Nav_Downloads' in Internet
        Explorer.

        This command line shows how to automatically open the last opened urls.
#>
[CmdletBinding(DefaultParameterSetName='Export')]
Param
(
    [Parameter(Mandatory=$true,Position=0,ParameterSetName='Export')]
    [Alias('path')][String]$ExportCsvFile,
    [Parameter(Mandatory=$true,Position=0,ParameterSetName='Import')]
    [Alias('Open')][String]$OpenURL
)

Function GetCurrentIEURL
{
    $IEObjs = @()
    $ShellWindows = (New-Object -ComObject Shell.Application).Windows()

    Foreach($IE in $ShellWindows)
    {
        $FullName = $IE.FullName
        If($FullName -ne $NULL)
        {
            $FileName = Split-Path -Path $FullName -Leaf

            If($FileName.ToLower() -eq "iexplore.exe")
            {
                $Title = $IE.LocationName
                $URL = $IE.LocationURL
                $IEObj = New-Object -TypeName PSObject -Property @{Title = $Title; URL = $URL}
                $IEObjs += $IEObj
            }
        }
    }

    $IEObjs
}

If($ExportCsvFile)
{
    $CurrentIEURL = GetCurrentIEURL
    If($CurrentIEURL -ne $null)
    {
        $CurrentIEURL|Export-Csv -Path "$ExportCsvFile" -NoTypeInformation
        Write-Host "Successfully exported csv file on '$ExportCsvFile'"
    }
    Else
    {
        Write-Warning "Can not find any URL of Tab."
    }
}

If($OpenURL)
{
    If(Test-Path -Path $OpenURL)
    {
        If((Get-ChildItem -Path $OpenURL).Extension -eq ".csv")
        {
            $URLs = (Import-Csv -Path $OpenURL).URL
            
            $IEApplication = New-Object -ComObject InternetExplorer.Application
            $navOpenInBackgroundTab = 0x1000
            $IEApplication.Visible = $true 

            ForEach($URL in $URLs)
            {
                Try
                {
                    $IEApplication.Navigate($URL, $navOpenInBackgroundTab)
                    While($IEApplication.Busy)
                    {
                        Start-Sleep -Millisecond 100
                    }
                    Write-Host "Successfully open '$URL' in Internet Explorer."
                }
                Catch
                {
                    Write-Host "Failed to '$URL' in Internet Explorer."
                }
            }
        }
        Else
        {
            Write-Warning "The file is not a csv file, please check it."
        }
    }
    Else
    {
        Write-Warning "The path '$OpenURL' cannot find. Please make sure that it exists."
    }
}